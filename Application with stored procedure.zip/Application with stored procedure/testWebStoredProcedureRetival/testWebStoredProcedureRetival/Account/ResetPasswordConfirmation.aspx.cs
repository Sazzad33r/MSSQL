﻿using System.Web.UI;

namespace testWebStoredProcedureRetival.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}